
using namespace std;

const double PI=3.1416;

class punto {
    public:
	int x;
	int y;
        punto() {x = 0; y=0;};
	punto(int i, int j) {x = i; y = j;}
};
/*Defina una clase Forma que tenga los siguientes miembros de datos:
- Color
- Coordenada del centro de la forma (objeto Punto)
- Nombre de la forma (char *)
Y, al menos, las siguientes funciones miembro:
- Imprimir
- Obtener y cambiar el color
- Mover la forma (o sea, su centro)*/
class forma  {
    protected:
	string color;
	punto centro;
	string nombre;
    public:
	forma(string);
	forma(string, punto);
	virtual ~forma()			{};
	virtual void imprimir();
	virtual int area()			{return(-1);};
	string get_color();
	void set_color(string);
	void mover_centro(punto);
	friend ostream & operator << (ostream & salida, const forma & f);
};
/*Defina una clase derivada Rect�ngulo que tenga los siguientes miembros como
datos:
- Lado menor.
- Lado mayor.
Y, al menos, las siguientes funciones miembro:
- Imprimir. Debe imprimir qu� se trata de un rect�ngulo mostrando su nombre,
color, centro y lado. Deber�a usarse la funci�n Imprimir de la clase base para
realizar parte de este trabajo.
- Calcular el �rea (lado menor * lado mayor).
- Calcular el per�metro. (2 * lado menor + 2 * lado mayor).
- Cambiar el tama�o del rect�ngulo. Recibe como par�metro un factor de escala.
As�, por ejemplo, si el factor vale 2, el rect�ngulo duplicar� su tama�o y si es 0,5
se reducir� a la mitad.
Realice un programa que pruebe el funcionamiento de estas clases. Debe crear
objetos y comprobar el correcto funcionamiento de las funciones miembro.*/
class rectangulo: public forma {
    protected:
	int lado_m;
	int lado_M;
    public:
	rectangulo(string, int, int);
	rectangulo(string, punto, int, int);
	virtual void imprimir();
	virtual int area();
	virtual int perimetro();
	void cambiar_tamano(double);
	friend ostream & operator << (ostream & salida, const rectangulo & r);
};

/*Defina una clase Elipse derivada de forma. Recordatorio: una elipse queda
definida por su radio mayor (R) y su radio menor (r), tal que el �rea de una elipse
es igual a p*(R*r).*/
class elipse: public forma {
    protected:
	int radio_m;
	int radio_M;
    public:
	elipse(string, int, int);
	elipse(string, punto, int, int);
	virtual void imprimir();
	virtual int area();
	friend ostream & operator << (ostream & salida, const elipse & e);
};

/*Defina una clase Cuadrado derivada de la clase Rect�ngulo.*/
class cuadrado: public rectangulo {
    public:
	cuadrado(string, int);
	cuadrado(string, punto, int);
	virtual void imprimir();
	friend ostream & operator << (ostream & salida, const cuadrado & c);
};

/*Defina una clase Circulo derivada de la clase Elipse.*/
class circulo: public elipse {
    public:
	circulo(string, int);
	circulo(string, punto, int);
	virtual int perimetro();
	virtual void imprimir();
	friend ostream & operator << (ostream & salida, const circulo & c);
};

