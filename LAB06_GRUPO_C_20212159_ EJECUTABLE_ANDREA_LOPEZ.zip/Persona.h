#include <iostream>
using namespace std;
class Persona{
	private:
		string nombre;
	public:
		Persona(string _nombre);
		void Edad(int aA , int mA, int fA, int aN, int mN, int fN);
};
Persona::Persona(string _nombre){
	nombre=_nombre;
}
void Persona::Edad( int aA , int mA, int fA, int aN, int mN, int fN){
   int rdias , rmes;
if ( fA < fN )//dias
{
fA = fA + 30;
mA = mA - 1;
rdias = fA - fN;
}
else
rdias = fA - fN;
if( mA < mN )//meses
{
mA = mA + 12;
aA = aA - 1 ;
rmes = mA - mN;
}
else
rmes = mA - mN;
cout<<"Nombre: "<<nombre<<endl;
cout << "Edad: "<<endl;
cout << " Anio: " <<aA - aN << endl;
cout << " Mes: " << rmes << endl;
cout << " Dia: " << rdias << endl;
}
