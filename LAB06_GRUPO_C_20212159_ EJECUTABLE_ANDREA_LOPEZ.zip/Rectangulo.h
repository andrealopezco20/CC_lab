/*Implemente un programa con clases que calcule el �rea de un rect�ngulo y per�metro.*/
#include <iostream>
using namespace std;
class Rectangulo{
	private:
		int a,b;
	public:
		Rectangulo(int _altura,int _ancho);
		void Area();
		void Perimetro();
  
};
Rectangulo::Rectangulo(int _altura,int _ancho){
a=_altura;
b=_ancho;
}
void Rectangulo::Area(){
	cout<<"El area es "<<a*b<<endl;
}
void Rectangulo::Perimetro(){
	cout<<"El perimetro es "<<2*(a+b)<<endl;
}
/*int main(){
	int a,b;
   cout<<"Ingrese a: "<<endl;
   cin>>a;
   cout<<"Ingrese b: "<<endl;
   cin>>b;
   Rectangulo r1(a,b);
   r1.Area();
   r1.Perimetro();
system("pause");
    return 0;
 
}*/

