#include <iostream>
using namespace std;
class Alumno{
   private:
   string nombre;
   int CUI;
   public:
   Alumno(string _nombre,int _CUI);
   void Promedio();
};
Alumno::Alumno(string _nombre,int _CUI){
	nombre=_nombre;
	CUI=_CUI;
}
void Alumno::Promedio(){
   int a,b,c;
   cout<<"Nota 1?"<<endl;
   cin>>a;
   cout<<"Nota 2?"<<endl;
   cin>>b;
   cout<<"Nota 3?"<<endl;
   cin>>c;
   int promedio;
   promedio=(a+b+c)/3;
   cout<<"Nombre: "<<nombre<<endl;
   cout<<"CUI: "<<CUI<<endl;
   cout<<"Su promedio es "<<promedio<<endl;
   if (promedio>10.5){
       cout<<"Aprobo la asignatura de CC"<<endl;
   }
   else if(promedio<10.5){
       cout<<"No aprobo la asignatura de CC"<<endl;
   }
 
}

 
