#include <iostream>
#include <sstream>
#include <string>
#include <ctime>
#include <stdio.h>
#include <stdlib.h>
#include <iomanip>
using namespace std;
class Matriz {
	private:
		int num;
	public:
		void Buscar();
};
void Matriz::Buscar(){
	int M[3][3];
	int f,c,fi,co,num;
	bool verificar= false;
	srand(time(NULL));
	for(f=0;f<3;f++){
		for(c=0;c<3;c++){
			M[f][c]=1+ rand() % 9;
		}
	}
	for(f=0;f<3;f++){
		for(c=0;c<3;c++){
			cout<<M[f][c]<<" ";
		}cout<<endl;
	}
	cout<<"Valor a buscar?"<<endl;
	cin>>num;
	for(f=0;f<3;f++){
		for(c=0;c<3;c++){
			if(num==M[f][c]){
				c=co;
				f=fi;
				verificar=true;
			}
		}
		}
		if (verificar= true){
			cout<<"El valor "<<num<<" se encuentra en ["<<co<<"]["<<fi<<"]"<<endl;
		}
		else {
			cout<<"Valor no encontrado"<<endl;
		}
	}

